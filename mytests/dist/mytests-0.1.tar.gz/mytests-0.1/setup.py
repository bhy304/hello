from setuptools import setup

setup(name='mytests',
      version='0.1',
      description='test module by Jade',
      url='https://github.com/indiflex/hello/mytests',
      author='Jade IndiFlex',
      author_email='indiflex1@gmail.com',
      license='MIT',
      packages=['mytests'],
      install_requires=['requests'],
      zip_safe=False)
